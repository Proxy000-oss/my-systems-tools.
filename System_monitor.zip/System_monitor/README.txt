en
"Performance Monitor" monitors the RAM and processor. You need to run "System.exe"!
ru
"Системный монитор" наблюдает за оперативной памятью и процессором. Запускать нужно "System.exe"!